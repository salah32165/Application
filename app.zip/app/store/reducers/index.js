import {combineReducers} from "redux";
import User from "./users-reducer";

const RoutReducer = combineReducers ({
User
});
export default RoutReducer ;