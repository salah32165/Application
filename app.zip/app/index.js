

import React from 'react';
import {StyleSheet,View} from 'react-native';
import {RoutNavigator} from "./routes"


const App=() => {
  const Nav = RoutNavigator(); 
  return (
  <View style ={styles.container}>
    <Nav/>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex : 1,
   backgroundColor :"#fff",
 
  
  },
});

export default App;
