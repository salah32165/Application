import React from 'react';
import {StyleSheet,View,Text} from 'react-native';



const GamesComponent =() => {
  
  return (
  <View style >
    <Text>Hello I'm the GAMES</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex : 1,
   backgroundColor :"#fff",
 
  
  },
});

export default GamesComponent;