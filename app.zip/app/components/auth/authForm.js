import React , {Component} from 'react';
import {View,Text,Image} from 'react-native';
import Input from "../../utils/Forms/Input";

class  AuthForm extends Component {
  state = {
type : "Login",
action : "Login",
actionMode : "I want to register",
hasErrors : false,
form : {
  email : {
    value :"",
    valide : false , 
    type : "Textinput",
    rules : {
isRequired : true,
isEmail : true ,
    }
  },
  password : {
    value :"",
    valide : false , 
    type : "Textinput",
    rules : {
isRequired : true,
minLength: 6 ,
    }
  } ,
  confirmPassword : {
    value :"",
    valide : false , 
    type : "Textinput",
    rules : {
confirmPassword : "password",
    }
  }
}
  }; 
render (){
  
  return(
  <View style = {{flex : 1
    
  }} >
    <Input
     
    placeholder = "Enter email"
    placeholderTextColor = "#cecece"
    type = {this.state.form.email.type}
    value = {this.state.form.email.value}
    autoCapitalize = {"none"}
    />
    
    </View>
  )
}
};

export default AuthForm;