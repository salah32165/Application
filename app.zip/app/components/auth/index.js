import React,{Component} from 'react';
import {StyleSheet,View,ScrollView,ActivityIndicator} from 'react-native';

import AuthLogo from "./authLogo";
import AuthForm from "./authForm";

class AuthComponent extends Component  {
  state ={ 
    loading :false
  }
render() {
  if (this.state.loading){
    return (
    <View style = {styles.loading}>
     <ActivityIndicator/> 
    </View>
    )
    
  } else {
  return (
  <ScrollView style= {styles.container}>
<View>
<AuthLogo/>
<AuthForm/>
</View>
  </ScrollView>
  
  );
}
}
}
const styles = StyleSheet.create ({
container : {
flex : 1,
padding : 50,
backgroundColor : "#1d428a"
},
loading : {
flex : 1,
justifyContent : "center" , 
backgroundColor : "#fff",
alignItems : "center" ,


}
});
export default AuthComponent ;


