import React from 'react';
import {StyleSheet,View,Text} from 'react-native';



const NewsComponent =() => {
  
  return (
  <View style >
    <Text>Hello I'm the News</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex : 1,
   backgroundColor :"#fff",
 
  
  },
});

export default NewsComponent;